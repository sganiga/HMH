package objects;

import java.util.List;

public class Locations {
	private List<City> location_suggestions;
	private String status;
	private String has_more;
	private String has_total;
	
	public List<City> getLocation_suggestions() {
		return location_suggestions;
	}
	public void setLocation_suggestions(List<City> cities) {
		this.location_suggestions = location_suggestions;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getHas_more() {
		return has_more;
	}
	public void setHas_more(String has_more) {
		this.has_more = has_more;
	}
	public String getHas_total() {
		return has_total;
	}
	public void setHas_total(String has_total) {
		this.has_total = has_total;
	}

}
