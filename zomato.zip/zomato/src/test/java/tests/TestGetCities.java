package tests;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import objects.Locations;

import static org.hamcrest.Matchers.equalTo;

public class TestGetCities {

  // Specifies a default request specification that will be sent with each request	 
  RequestSpecification reqSpec = new RequestSpecBuilder()
				.setAccept(ContentType.JSON)
				.setBaseUri("https://developers.zomato.com/api/v2.1")
				.addHeader("user-key", "8c9bccba405c0b528bf30d4a254510ab")
				.build();
  
  /* Test to verify expected response code and body when sending GET request 
   * with city name parameter.
   */
  @Test
  public void testValidCityInput() {  
	 String cityName = "Dublin";
	  
	 RestAssured.given()
			 	.spec(reqSpec)
			 	.param("q", cityName)
		
			 	.when()
				.get("/cities")
				
	            .then()
	            .assertThat()
	            .statusCode(200)
	            .extract().as(Locations.class);

  }
  
  /* Test to verify expected response code and body when sending GET request 
   * with city name parameter with maximum results to be displaed count.
   */
  @Test
  public void testValidCityInputWithDisplaycount() {  
	  String cityName = "Dublin";
	 int maxResultsToDisplay = 1;
	 
	 RestAssured.given()
			 	.spec(reqSpec)
			 	.param("q", cityName)
			 	.param("count", maxResultsToDisplay)
			 
			 	.when()
				.get("/cities")
				
	            .then()
	            .assertThat()
	            .statusCode(200)
	            .extract().as(Locations.class);

  }
  
  /* Test to verify expected response code and body when sending GET request 
   * with city name parameter.
   */
  @Test
  public void testValidLocationInput() {  
	 Double latitude = 12.9716;
	 Double longitude = 77.5946;
	 
	 RestAssured.given()
			 	.spec(reqSpec)
			 	.param("lat", latitude)
			 	.param("lon", longitude)
			 	
			 	.when()
				.get("/cities")
				
	            .then()
	            .assertThat()
	            .statusCode(200)
	            .extract().as(Locations.class);

  }
  
  /* Test to verify expected response code and body when sending GET request 
   * with city id parameter.
   */
  @Test
  public void testValidCityIdInput() {  
	 int cityId = 4;
	 
	 RestAssured.given()
			 	.spec(reqSpec)
			 	.param("id", cityId)
			 
			 	.when()
				.get("/cities")
				
	            .then()
	            .assertThat()
	            .statusCode(200)
	            .extract().as(Locations.class);

  }
  
  /* Test to verify error response when sending invalid user api-key 
   * for id in the post request
   */
  @Test
  public void testInvalidAPIKey() {  
	 String cityName = "Dublin";
	  
	 RestAssured.given()
			 	.spec(reqSpec)
		        .header("user-key", "invalidAPIKey")
			 	.when()
				.get("/cities?q="+cityName)
				
	            .then()
	            .assertThat()
	            .statusCode(403)
	 			.body("status", equalTo("Forbidden"))
	 			.body("message", equalTo("Invalid API Key"));
  }
  
}

